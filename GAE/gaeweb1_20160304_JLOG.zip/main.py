# -*- coding: utf-8 -*-
import os
import json
import datetime
import webapp2
import model as m
from datetime import timedelta
from webapp2_extras import sessions
from google.appengine.ext import db
from google.appengine.ext.webapp import template

class BaseHandler(webapp2.RequestHandler):
    def dispatch(self):
        # Get a session store for this request.
        self.session_store=sessions.get_store(request=self.request)
        try:
            #Dispatch the request.
            webapp2.RequestHandler.dispatch(self)
        finally:
            #Save all sessions.
            self.session_store.save_sessions(self.response)
    @webapp2.cached_property
    def session(self):
        #Returns a session using the default cookie key.
        sess=self.session_store.get_session()
        #add some default values:
        if not sess.get("theme"):
            sess["theme"]="default"
        return sess
    def check_login(self):
        account=self.session.get('account')
        if account is None:
            self.redirect("/login")

class login(webapp2.RequestHandler):
    def get(self):
        s=m.Settings.get_by_key_name("settings")
        info={}
        if s is None:
            info["site_title"]=""
            info["site_theme"]="ui-cupertino"
        else:
            info["site_title"]=s.site_title
            info["site_theme"]=s.site_theme
        url="templates/login.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{"info":info})
        self.response.out.write(content)

class check_member(BaseHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=m.Members.gql("""WHERE account= :1  
                               AND password= :2""",
                               account,password)
        mb=query.get()
        if mb is None: #user not existed
            content='{"result":"failure","reason":"帳號或密碼錯誤"}'
        else: #user existed
            #check site_state (on/off)
            s=m.Settings.get_by_key_name("settings")
            site_state=s.site_state
            #go main page if system is on or user is admin
            if site_state=="on" or mb.is_admin:
                #save session
                self.session['account']=mb.account     
                self.session['theme']=mb.theme         
                self.session['is_admin']=mb.is_admin
                #update last_login_time & login_count of the user
                mb.last_login_time=datetime.datetime.now() + timedelta(hours=+8)
                mb.login_count=mb.login_count + 1
                mb.put()
                content='{"result":"success"}'
            else: #system is on maintanance (off) and not admin
                content='{"result":"failure","reason":"系統維護中, 請稍候."}'
        self.response.out.write(content)    

class logout(BaseHandler):
    def get(self):
        #clear session & back to login
        self.session.clear()
        self.redirect("/login")

class change_theme(BaseHandler):
    def get(self):
        self.check_login()
        theme=self.request.get("theme")  #get selected theme
        self.session['theme']=theme  #update user session
        account=self.session.get('account')
        member=m.Members.get_by_key_name(account)  #retrieve entity
        member.theme=theme  
        member.put()  #update user theme in datastre

class hometabs(BaseHandler):
    def get(self):
        self.check_login()
        hometabs=m.Hometabs.all()
        hometabs.order("tab_order")  #sort by tab_order
        tabs=[]  #for storing tab objects
        is_admin=self.session.get('is_admin')  #True/False
        for t in hometabs:
            tab={}
            tab["tab_label"]=t.tab_label
            tab["tab_link"]=t.tab_link
            if t.tab_admin:  #this tab is for admin only
                if is_admin: #current user is admin
                    tabs.append(tab)
            else:  #this tab is for registered users
                tabs.append(tab)
        url="templates/hometabs.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{"tabs":tabs}) 
        self.response.out.write(content)

class jlogtabs(BaseHandler):
    def get(self):
        self.check_login()
        jlogtabs=m.Jlogtabs.all()
        jlogtabs.order("tab_order")  #sort by tab_order
        tabs=[]  #for storing tab objects
        is_admin=self.session.get('is_admin')  #True/False
        for t in jlogtabs:
            tab={}
            tab["tab_label"]=t.tab_label
            tab["tab_link"]=t.tab_link
            if t.tab_admin:  #this tab is for admin only
                if is_admin: #current user is admin
                    tabs.append(tab)
            else:  #this tab is for registered users
                tabs.append(tab)
        url="templates/jlogtabs.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{"tabs":tabs}) 
        self.response.out.write(content)

class jlog_home(BaseHandler):
    def get(self):
        self.check_login()
        url="templates/jlog_home.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class jlog_knowledge(BaseHandler):
    def get(self):
        self.check_login()
        url="templates/jlog_knowledge.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class jlog_admin(BaseHandler):
    def get(self):
        self.check_login()
        url="templates/jlog_admin.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class home(BaseHandler):
    def get(self):
        self.check_login()
        url="templates/home.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class list_visitors(BaseHandler):
    def get(self):
        self.check_login()
        url="templates/list_visitors.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors(BaseHandler):
    def post(self):
        self.check_login()
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        search_field=self.request.get("search_field")
        search_what=self.request.get("search_what")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="visit_time"
        if not len(order):
            order="desc"
        if len(search_field):
            query=m.Visitors.all()
            query.filter(search_field + " >= ", search_what)
            query.filter(search_field + " < ", search_what + u'\ufffd')
        else:
            query=m.Visitors.gql("ORDER BY %s %s" % (sort, order))
        visitors=query.fetch(rows, (page-1)*rows)
        rows=[]
        for v in visitors:
            #format to string for JSON serializable
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
        count=query.count()
        obj={"total":count,"rows":rows}
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class remove_visitors(BaseHandler):
    def post(self):
        self.check_login()
        visitors=m.Visitors.all()
        for v in visitors:
            db.delete(v)
        content='{"status":"success"}'            
        self.response.out.write(content)

class list_members(BaseHandler):
    def get(self):
        self.check_login()
        #query Themes from datastore
        themes=m.Themes.all()
        info={}
        theme_list=[]
        for t in themes:
            theme_list.append(t.theme)
        info["themes"]=theme_list
        url="templates/list_members.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'info':info}) 
        self.response.out.write(content)

class get_members(BaseHandler):
    def post(self):
        self.check_login()
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        search_field=self.request.get("search_field")
        search_what=self.request.get("search_what")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="account"
        if not len(order):
            order="asc"
        if len(search_field):
            query=m.Members.all()
            query.filter(search_field + " >= ", search_what)
            query.filter(search_field + " < ", search_what + u'\ufffd')
        else:
            query=m.Members.gql("ORDER BY %s %s" % (sort, order))
        count=query.count()
        mbs=query.fetch(rows, (page-1)*rows)
        rows=[]  #for storing objects
        for mb in mbs:
            #format to string for JSON serializable
            last_login_time=mb.last_login_time.strftime("%Y-%m-%d %H:%M:%S")
            member={"account":mb.account,
                    "password":mb.password,
                    "name":mb.name,
                    "theme":mb.theme,
                    "is_admin":mb.is_admin,
                    "email":mb.email,
                    "mobile":mb.mobile,
                    "login_count":mb.login_count,
                    "last_login_time":last_login_time}
            rows.append(member)
        obj={"total":count,"rows":rows}  #Easyui datagrid json format
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class add_member(BaseHandler):
    def post(self):
        self.check_login()
        account=self.request.get("account")
        password=self.request.get("password")
        name=self.request.get("name")
        theme=self.request.get("theme")
        is_admin=self.request.get("is_admin")
        email=self.request.get("email", default_value="foo@bar.com")
        mobile=self.request.get("mobile", default_value="0933123456")
        #trans string to boolean
        if is_admin=="True":
            is_admin=True
        else:
            is_admin=False
        #check entity if exist
        mb=m.Members.get_by_key_name(account)
        if mb: #already exist
            result='{"status":"failure","reason":"帳號已存在!"}'  
        else:  #new member
            member=m.Members(key_name=account,
                account=account,
                password=password,
                name=name,
                theme=theme,
                is_admin=is_admin,
                email=email,
                mobile=mobile
                )
            member.put()
            result='{"status":"success"}'         
        self.response.out.write(result) 

class update_member(BaseHandler):
    def post(self):
        self.check_login()
        account=self.request.get("account")
        password=self.request.get("password")
        name=self.request.get("name")
        theme=self.request.get("theme")
        is_admin=self.request.get("is_admin")
        email=self.request.get("email")
        mobile=self.request.get("mobile", default_value="")
        #trans string to boolean
        if is_admin=="True":
            is_admin=True
        else:
            is_admin=False
        #get entity from store
        mb=m.Members.get_by_key_name(account)
        if mb: #entity exist
            mb.account=account
            mb.password=password
            mb.name=name
            mb.theme=theme
            mb.is_admin=is_admin
            mb.email=email
            mb.mobile=mobile
            mb.put()
            result='{"status":"success"}'
        else:  #member not existed
            result='{"status":"failure","reason":"使用者不存在!"}'         
        self.response.out.write(result)

class remove_member(BaseHandler):
    def post(self):
        self.check_login()
        account=self.request.get("account")
        #get entity from store
        mb=m.Members.get_by_key_name(account)
        if mb: #entity exist
            db.delete(mb)            
            result='{"status":"success"}'
        else:  #member not existed
            result='{"status":"failure","reason":"使用者不存在!"}'         
        self.response.out.write(result) 

class list_headerlinks(BaseHandler):
    def get(self):
        self.check_login()
        url="templates/list_headerlinks.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_headerlinks(BaseHandler):
    def post(self):
        self.check_login()
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="sequence"
        if not len(order):
            order="asc"
        query=m.Headerlinks.gql("ORDER BY %s %s" % (sort, order))
        count=query.count()
        links=query.fetch(rows, (page-1)*rows)
        rows=[]  #for storing objects
        for h in links:
            link={"name":h.name,
                  "title":h.title,
                  "url":h.url,
                  "target":h.target,
                  "sequence":h.sequence,
                  "hint":h.hint}
            rows.append(link)
        obj={"total":count,"rows":rows}  #Easyui datagrid json format
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class add_headerlink(BaseHandler):
    def post(self):
        self.check_login()
        name=self.request.get("name")
        #check entity if exist
        link=m.Headerlinks.get_by_key_name(name)
        if link: #already exist
            result='{"status":"failure","reason":"連結名稱已存在!"}'  
        else:  #new link
            headerlink=m.Headerlinks(key_name=name,name=name,
                title=self.request.get("title"),
                url=self.request.get("url"),
                target=self.request.get("target"),
                sequence=int(self.request.get("sequence")),
                hint=self.request.get("hint")
                )
            headerlink.put()
            result='{"status":"success"}'         
        self.response.out.write(result) 

class update_headerlink(BaseHandler):
    def post(self):
        self.check_login()
        name=self.request.get("name")
        #get entity from store
        link=m.Headerlinks.get_by_key_name(name)
        if link: #entity exist
            link.title=self.request.get("title")
            link.url=self.request.get("url")
            link.target=self.request.get("target")
            link.sequence=int(self.request.get("sequence"))
            link.hint=self.request.get("hint")
            link.put()
            result='{"status":"success"}'
        else:  #link not existed
            result='{"status":"failure","reason":"連結不存在!"}'         
        self.response.out.write(result) 

class remove_headerlink(BaseHandler):
    def post(self):
        self.check_login()
        name=self.request.get("name")
        #get entity from store
        link=m.Headerlinks.get_by_key_name(name)
        if link: #entity exist
            db.delete(link)            
            result='{"status":"success"}'
        else:  #link not existed
            result='{"status":"failure","reason":"連結不存在!"}'         
        self.response.out.write(result) 

class list_navblocks(BaseHandler):
    def get(self):
        self.check_login()
        url="templates/list_navblocks.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_navblocks(BaseHandler):
    def post(self):
        self.check_login()
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="sequence"
        if not len(order):
            order="asc"
        query=m.Navblocks.gql("ORDER BY %s %s" % (sort, order))
        count=query.count()
        blocks=query.fetch(rows, (page-1)*rows)
        rows=[]  #for storing objects
        for b in blocks:
            block={"name":b.name,
                   "title":b.title,
                   "sequence":b.sequence,
                   "display":b.display}
            rows.append(block)
        obj={"total":count,"rows":rows}  #Easyui datagrid json format
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class add_navblock(BaseHandler):
    def post(self):
        self.check_login()
        name=self.request.get("name")
        display=self.request.get("display")
        if display=="True":
            display=True
        else:
            display=False
        #check entity if exist
        block=m.Navblocks.get_by_key_name(name)
        if block: #already exist
            result='{"status":"failure","reason":"導覽區塊已存在!"}'  
        else:  #new block
            navblock=m.Navblocks(key_name=name,name=name,
                title=self.request.get("title"),
                sequence=int(self.request.get("sequence")),
                display=display
                )
            navblock.put()
            result='{"status":"success"}'         
        self.response.out.write(result) 

class update_navblock(BaseHandler):
    def post(self):
        self.check_login()
        name=self.request.get("name")
        display=self.request.get("display")
        if display=="True":
            display=True
        else:
            display=False
        #get entity from store
        block=m.Navblocks.get_by_key_name(name)
        if block: #entity exist
            block.title=self.request.get("title")
            block.sequence=int(self.request.get("sequence"))
            block.display=display
            block.put()
            result='{"status":"success"}'
        else:  #block not existed
            result='{"status":"failure","reason":"導覽區塊不存在!"}'         
        self.response.out.write(result) 

class remove_navblock(BaseHandler):
    def post(self):
        self.check_login()
        name=self.request.get("name")
        #get entity from store
        block=m.Navblocks.get_by_key_name(name)
        if block: #entity exist
            db.delete(block)  
            #delete navlinks belong to this navblock
            query=m.Navlinks.all()
            links=query.filter("block_name",name) 
            for link in links:  
                db.delete(link)
            result='{"status":"success"}'
        else:  #block not existed
            result='{"status":"failure","reason":"導覽區塊不存在!"}'         
        self.response.out.write(result) 

class list_navlinks(BaseHandler):
    def get(self):
        self.check_login()
        blocks=m.Navblocks.all()
        info=[]
        for b in blocks:
            block={}
            block["block_name"]=b.name
            block["block_title"]=b.title
            #block["block_title"]=b.title + " (" + b.name + ")"
            info.append(block)
        url="templates/list_navlinks.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{"info":info}) 
        self.response.out.write(content)

class get_navlinks(BaseHandler):
    def post(self):
        self.check_login()
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="sequence"
        if not len(order):
            order="asc"
        query=m.Navlinks.gql("ORDER BY %s %s" % (sort, order))
        count=query.count()
        links=query.fetch(rows, (page-1)*rows)
        rows=[]  #for storing objects
        for h in links:
            link={"name":h.name,
                  "title":h.title,
                  "url":h.url,
                  "target":h.target,
                  "sequence":h.sequence,
                  "block_name":h.block_name,
                  "hint":h.hint}
            rows.append(link)
        obj={"total":count,"rows":rows}  #Easyui datagrid json format
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class add_navlink(BaseHandler):
    def post(self):
        self.check_login()
        name=self.request.get("name")
        #check entity if exist
        link=m.Navlinks.get_by_key_name(name)
        if link: #already exist
            result='{"status":"failure","reason":"連結名稱已存在!"}'  
        else:  #new link
            navlink=m.Navlinks(key_name=name,name=name,
                title=self.request.get("title"),
                url=self.request.get("url"),
                target=self.request.get("target"),
                sequence=int(self.request.get("sequence")),
                block_name=self.request.get("block_name"),
                hint=self.request.get("hint")
                )
            navlink.put()
            result='{"status":"success"}'         
        self.response.out.write(result) 

class update_navlink(BaseHandler):
    def post(self):
        self.check_login()
        name=self.request.get("name")
        #get entity from store
        link=m.Navlinks.get_by_key_name(name)
        if link: #entity exist
            link.title=self.request.get("title")
            link.url=self.request.get("url")
            link.target=self.request.get("target")
            link.sequence=int(self.request.get("sequence"))
            link.block_name=self.request.get("block_name")
            link.hint=self.request.get("hint")
            link.put()
            result='{"status":"success"}'
        else:  #link not existed
            result='{"status":"failure","reason":"連結不存在!"}'         
        self.response.out.write(result) 

class remove_navlink(BaseHandler):
    def post(self):
        self.check_login()
        name=self.request.get("name")
        #get entity from store
        link=m.Navlinks.get_by_key_name(name)
        if link: #entity exist
            db.delete(link)            
            result='{"status":"success"}'
        else:  #link not existed
            result='{"status":"failure","reason":"連結不存在!"}'         
        self.response.out.write(result) 

class settings(BaseHandler):
    def get(self):
        self.check_login()
        info={}  #for storing parameters
        #query settings from datastore
        settings=m.Settings.get_by_key_name("settings")
        if settings: #entity exist
            info["site_title"]=settings.site_title
            info["site_theme"]=settings.site_theme
            info["site_state"]=settings.site_state
        else:
            info["site_title"]=""
            info["site_theme"]="default"
            info["site_state"]="off"
        #query Themes from datastore
        themes=m.Themes.all()
        theme_list=[]
        for t in themes:
            theme_list.append(t.theme)
        info["themes"]=theme_list
        url="templates/settings.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'info':info}) 
        self.response.out.write(content)

class update_settings(BaseHandler):
    def post(self):
        self.check_login()
        #get entity from store
        settings=m.Settings.get_by_key_name("settings")
        if settings: #entity exist
            settings.site_title=self.request.get("site_title")
            settings.site_theme=self.request.get("site_theme")
            settings.site_state=self.request.get("site_state")
            settings.put()
            result='{"status":"success"}'
        else:  #entity not existed
            result='{"status":"failure"}'         
        self.response.out.write(result)

class member_settings(BaseHandler):
    def get(self):
        self.check_login()
        info={}  #for storing parameters
        account=self.session.get('account')
        #query settings from datastore
        mb=m.Members.get_by_key_name(account)
        info["password"]=mb.password
        info["theme"]=mb.theme
        info["email"]=mb.email
        info["mobile"]=mb.mobile
        #query Themes from datastore
        themes=m.Themes.all()
        theme_list=[]
        for t in themes:
            theme_list.append(t.theme)
        info["themes"]=theme_list
        url="templates/member_settings.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'info':info}) 
        self.response.out.write(content)

class update_member_settings(BaseHandler):
    def post(self):
        self.check_login()
        account=self.session.get('account')
        #get entity from store
        mb=m.Members.get_by_key_name(account)
        if mb: #entity exist
            mb.password=self.request.get("password")
            mb.theme=self.request.get("theme")
            mb.email=self.request.get("email")
            mb.mobile=self.request.get("mobile")
            mb.put()
            result='{"status":"success"}'
        else:  #entity not existed
            result='{"status":"failure"}'         
        self.response.out.write(result)

class MainHandler(BaseHandler):
    def get(self):  
        #save visitor info first
        ip=self.request.remote_addr
        user_agent=self.request.headers.get("User-Agent")
        # or user_agent=os.environ.get("HTTP_USER_AGENT")
        visitor=m.Visitors()
        visitor.ip=ip
        #adapt UTC to Taipei Time Zone
        visitor.visit_time=datetime.datetime.now() + timedelta(hours=+8)
        visitor.user_agent=user_agent
        visitor.ip_list=list(ip)
        visitor.user_agent_list=list(user_agent)
        visitor.put()
        #check login session
        self.check_login()
        #pass: already login, render main.htm
        info={}  #for storing parameters
        #create param: account, site_title, theme
        account=self.session.get('account')
        info["account"]=account
        s=m.Settings.get_by_key_name("settings")
        info["site_title"]=s.site_title
        theme=self.session.get('theme')
        info["theme"]=theme
        #create param: greeting
        today=datetime.date.today()
        week=[u"一",u"二",u"三",u"四",u"五",u"六",u"日"]
        info["greeting"]=u"您好! " + unicode(account) + u", 今天是 " + \
            unicode(str(today.year)) +  u" 年 " + unicode(str(today.month)) + \
            u" 月 " + unicode(str(today.day)) + u" 日 星期" + \
            week[today.weekday()]
        #create param: themes
        theme_list=[]
        themes=m.Themes.all()
        for t in themes:
            theme_list.append(t.theme)
        info["themes"]=theme_list
        #create param: headerlinks
        headerlinks=m.Headerlinks.all()
        headerlinks.order("sequence")  #sort by sequence
        link_list=[]  #for storing headerlinks objects
        for h in headerlinks:
            link={}
            link["title"]=h.title
            link["url"]=h.url
            link["target"]=h.target
            link["sequence"]=h.sequence
            link["hint"]=h.hint
            link_list.append(link)
        info["headerlinks"]=link_list
        #create param: navblocks & navlinks
        navblocks=m.Navblocks.all()
        navblocks.filter("display =",True)
        navblocks.order("sequence")  #sort by sequence            
        navblock_list=[]  #for storing navblocks objects
        for nb in navblocks:
            navblock={}
            navblock["title"]=nb.title  #store block title
            #query nvavlinks belongs to this block
            query=m.Navlinks.all()
            navlinks=query.filter("block_name =",nb.name)
            navlinks.order("sequence")
            navlink_list=[]  #for storing navblinks objects 
            for nl in navlinks:
                navlink={}
                navlink["title"]=nl.title
                navlink["url"]=nl.url
                navlink["target"]=nl.target
                navlink["hint"]=nl.hint
                navlink_list.append(navlink) #store this link
            navblock["navlinks"]=navlink_list #store block links 
            navblock_list.append(navblock)  #store this block
        info["navblocks"]=navblock_list
        url="templates/main.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'info':info}) 
        self.response.out.write(content)

config={}
config['webapp2_extras.sessions']={'secret_key':'my-super-secret-key'}
app = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/login', login),
    ('/check_member', check_member),
    ('/logout', logout),
    ('/hometabs', hometabs),
    ('/home', home),
    ('/change_theme', change_theme),
    ('/list_visitors', list_visitors),
    ('/get_visitors', get_visitors),
    ('/list_members', list_members),
    ('/get_members', get_members),
    ('/remove_visitors', remove_visitors),
    ('/add_member', add_member),
    ('/update_member', update_member),
    ('/remove_member', remove_member),
    ('/list_headerlinks', list_headerlinks),
    ('/get_headerlinks', get_headerlinks),
    ('/add_headerlink', add_headerlink),
    ('/update_headerlink', update_headerlink),
    ('/remove_headerlink', remove_headerlink),
    ('/list_navblocks', list_navblocks),
    ('/get_navblocks', get_navblocks),
    ('/add_navblock', add_navblock),
    ('/update_navblock', update_navblock),
    ('/remove_navblock', remove_navblock),
    ('/list_navlinks', list_navlinks),
    ('/get_navlinks', get_navlinks),
    ('/add_navlink', add_navlink),
    ('/update_navlink', update_navlink),
    ('/remove_navlink', remove_navlink),
    ('/settings', settings),
    ('/update_settings', update_settings),
    ('/member_settings', member_settings),
    ('/jlogtabs', jlogtabs),
    ('/jlog_home', jlog_home),
    ('/jlog_knowledge', jlog_knowledge),
    ('/jlog_admin', jlog_admin)
], debug=True, config=config)