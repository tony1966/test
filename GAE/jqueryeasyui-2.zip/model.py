# -*- coding: utf-8 -*-
from google.appengine.ext import db

class Users(db.Model):
	account=db.StringProperty()
	password=db.StringProperty()
	e_mail=db.EmailProperty()