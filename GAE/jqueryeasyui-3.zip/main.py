# -*- coding: utf-8 -*-
import os
from google.appengine.ext.webapp import template
import webapp2
import model as m
from google.appengine.ext import db

class easyui_1(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class easyui_2(webapp2.RequestHandler):
    def get(self):
        theme=self.request.get('theme',default_value='default')
        url="templates/easyui_2.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'theme':theme}) 
        self.response.out.write(content)

class easyui_3(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_3.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class easyui_4(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_4.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class login_4(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=db.GqlQuery("""SELECT * FROM Members 
                             WHERE account= :1 
                             AND password= :2""",
                             account,password)
        result=query.get()
        if result: 
            content='{"result":"success"}'
        else:
            content='{"result":"failure","reason":"�b���αK�X���~"}'
        self.response.out.write(content)

class easyui_5(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_5.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class login_5(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=m.Members.gql("""WHERE account= :1  
                               AND password= :2""",
                               account,password)
        result=query.get()
        if result is None:  
            content='{"result":"failure","reason":"�b���αK�X���~"}'
        else:
            content='{"result":"success"}'            
        self.response.out.write(content)

class easyui_5_1(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_5_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class home(webapp2.RequestHandler):
    def get(self):
        url="templates/home.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class MainHandler(webapp2.RequestHandler):
    def get(self):
        url="templates/default.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

app = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/easyui_1', easyui_1),
    ('/easyui_2', easyui_2),
    ('/easyui_3', easyui_3),
    ('/easyui_4', easyui_4),
    ('/login_4', login_4),
    ('/easyui_5', easyui_5),
    ('/login_5', login_5),
    ('/easyui_5_1', easyui_5_1),
    ('/home', home)
], debug=True)