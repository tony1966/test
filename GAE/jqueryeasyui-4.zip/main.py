# -*- coding: utf-8 -*-
import os
from google.appengine.ext.webapp import template
import webapp2
import model as m
from google.appengine.ext import db
from google.appengine.api import users
from google.appengine.ext.webapp.util import login_required

class easyui_1(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class easyui_2(webapp2.RequestHandler):
    def get(self):
        theme=self.request.get('theme',default_value='default')
        url="templates/easyui_2.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'theme':theme}) 
        self.response.out.write(content)

class easyui_3(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_3.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class easyui_4(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_4.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class login_4(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=db.GqlQuery("""SELECT * FROM Members 
                             WHERE account= :1 
                             AND password= :2""",
                             account,password)
        result=query.get()
        if result: 
            content='{"result":"success"}'
        else:
            content='{"result":"failure","reason":"帳號或密碼錯誤"}'
        self.response.out.write(content)

class easyui_5(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_5.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class login_5(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=m.Members.gql("""WHERE account= :1  
                               AND password= :2""",
                               account,password)
        result=query.get()
        if result is None:  
            content='{"result":"failure","reason":"帳號或密碼錯誤"}'
        else:
            content='{"result":"success"}'            
        self.response.out.write(content)

class easyui_5_1(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_5_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class home(webapp2.RequestHandler):
    def get(self):
        url="templates/home.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class google_user_login_1(webapp2.RequestHandler):
    def get(self):
        user=users.get_current_user();
        if user:
            logout_url=users.create_logout_url(self.request.path)
            content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))  
        else:
            login_url=users.create_login_url(self.request.path)
            content=("您尚未登入 (<a href='%s'>登入</a>)" % login_url) 
        self.response.out.write(content)

class google_user_login_2(webapp2.RequestHandler):
    @login_required
    def get(self):
        user=users.get_current_user();
        logout_url=users.create_logout_url(self.request.path)
        content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))
        self.response.out.write(content)

class google_user_login_3(webapp2.RequestHandler):
    def get(self):
        user=users.get_current_user();
        logout_url=users.create_logout_url(self.request.path)
        nickname=user.nickname()
        content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))
        self.response.out.write(content)

class google_user_login_4(webapp2.RequestHandler):
    @login_required
    def get(self):
        url="templates/google_user_login_4.htm"
        user=users.get_current_user();
        nickname=user.nickname()
        email=user.email()
        logout_url=users.create_logout_url("/google_user_login_4")
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,
            {'nickname':nickname,'email':email,'logout_url':logout_url})
        self.response.out.write(content)

class google_user_login_5(webapp2.RequestHandler):
    @login_required
    def get(self):
        user=users.get_current_user();
        logout_url=users.create_logout_url(self.request.path)
        if users.is_current_user_admin():
            content="您是此應用程式的管理者!"
        else:
            content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))
        self.response.out.write(content)

class MainHandler(webapp2.RequestHandler):
    def get(self):
        url="templates/default.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

app = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/easyui_1', easyui_1),
    ('/easyui_2', easyui_2),
    ('/easyui_3', easyui_3),
    ('/easyui_4', easyui_4),
    ('/login_4', login_4),
    ('/easyui_5', easyui_5),
    ('/login_5', login_5),
    ('/easyui_5_1', easyui_5_1),
    ('/home', home),
    ('/google_user_login_1', google_user_login_1),
    ('/google_user_login_2', google_user_login_2),
    ('/google_user_login_3', google_user_login_3),
    ('/google_user_login_4', google_user_login_4),
    ('/google_user_login_5', google_user_login_5)
], debug=True)