# -*- coding: utf-8 -*-
from google.appengine.ext import db

class Members(db.Model):
    account=db.StringProperty()
    password=db.StringProperty()

class Visitors(db.Model):
    ip=db.StringProperty()
    ip_list=db.StringListProperty()
    visit_time=db.DateTimeProperty()
    user_agent=db.StringProperty()
    user_agent_list=db.StringListProperty()

member=Members(account="admin",password="aaa")
member.put()
member=Members(account="guest",password="guest")
member.put()