# -*- coding: utf-8 -*-
import os
from google.appengine.ext.webapp import template
import webapp2
import model as m
from google.appengine.ext import db
from google.appengine.api import users
from google.appengine.ext.webapp.util import login_required
import os
from datetime import timedelta, datetime
import json

class easyui_1(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class easyui_2(webapp2.RequestHandler):
    def get(self):
        theme=self.request.get('theme',default_value='default')
        url="templates/easyui_2.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'theme':theme}) 
        self.response.out.write(content)

class easyui_3(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_3.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class easyui_4(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_4.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class login_4(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=db.GqlQuery("""SELECT * FROM Members 
                             WHERE account= :1 
                             AND password= :2""",
                             account,password)
        result=query.get()
        if result: 
            content='{"result":"success"}'
        else:
            content='{"result":"failure","reason":"帳號或密碼錯誤"}'
        self.response.out.write(content)

class easyui_5(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_5.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class login_5(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=m.Members.gql("""WHERE account= :1  
                               AND password= :2""",
                               account,password)
        result=query.get()
        if result is None:  
            content='{"result":"failure","reason":"帳號或密碼錯誤"}'
        else:
            content='{"result":"success"}'            
        self.response.out.write(content)

class easyui_5_1(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_5_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class home(webapp2.RequestHandler):
    def get(self):
        url="templates/home.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class google_user_login_1(webapp2.RequestHandler):
    def get(self):
        user=users.get_current_user();
        if user:
            logout_url=users.create_logout_url(self.request.path)
            content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))  
        else:
            login_url=users.create_login_url(self.request.path)
            content=("您尚未登入 (<a href='%s'>登入</a>)" % login_url) 
        self.response.out.write(content)

class google_user_login_2(webapp2.RequestHandler):
    @login_required
    def get(self):
        user=users.get_current_user();
        logout_url=users.create_logout_url(self.request.path)
        content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))
        self.response.out.write(content)

class google_user_login_3(webapp2.RequestHandler):
    def get(self):
        user=users.get_current_user();
        logout_url=users.create_logout_url(self.request.path)
        nickname=user.nickname()
        content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))
        self.response.out.write(content)

class google_user_login_4(webapp2.RequestHandler):
    @login_required
    def get(self):
        url="templates/google_user_login_4.htm"
        user=users.get_current_user();
        nickname=user.nickname()
        email=user.email()
        logout_url=users.create_logout_url("/google_user_login_4")
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,
            {'nickname':nickname,'email':email,'logout_url':logout_url})
        self.response.out.write(content)

class google_user_login_5(webapp2.RequestHandler):
    @login_required
    def get(self):
        user=users.get_current_user();
        logout_url=users.create_logout_url(self.request.path)
        if users.is_current_user_admin():
            content="您是此應用程式的管理者!"
        else:
            content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))
        self.response.out.write(content)

class list_visitors_1(webapp2.RequestHandler):
    def get(self):
        query=m.Visitors.all()
        query.order("-visit_time")
        url="templates/list_visitors_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{"visitors":query}) 
        self.response.out.write(content)

class list_visitors_2(webapp2.RequestHandler):
    def get(self):
        url="templates/list_visitors_2.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors_2(webapp2.RequestHandler):
    def get(self):
        self.response.headers["Content-Type"]="application/json"
        query=m.Visitors.all()
        query.order("-visit_time")
        rows=[]
        count=0
        for v in query:
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
            count=count + 1
        obj={"total":count,"rows":rows}
        self.response.out.write(json.dumps(obj))

class list_visitors_3(webapp2.RequestHandler):
    def get(self):
        url="templates/list_visitors_3.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors_3(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        query=m.Visitors.all()
        query.order("-visit_time")
        visitors=query.fetch(rows, (page-1)*rows)
        rows=[]
        for v in visitors:
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
        count=query.count()
        obj={"total":count,"rows":rows}
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class list_visitors_4(webapp2.RequestHandler):
    def get(self):
        url="templates/list_visitors_4.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors_4(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="visit_time"
        if not len(order):
            order="desc"
        query=m.Visitors.gql("ORDER BY %s %s" % (sort, order))
        visitors=query.fetch(rows, (page-1)*rows)
        rows=[]
        for v in visitors:
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
        count=query.count()
        obj={"total":count,"rows":rows}
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class list_visitors_5(webapp2.RequestHandler):
    def get(self):
        url="templates/list_visitors_5.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors_5(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        search_field=self.request.get("search_field")
        search_what=self.request.get("search_what")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="visit_time"
        if not len(order):
            order="desc"
        if len(search_field):
            query=m.Visitors.all()
            query.filter(search_field + " >= ", search_what)
            query.filter(search_field + " < ", search_what + u'\ufffd') 
            if order=="desc":
                query.order("-" + search_field)
            else:
                query.order(search_field)
        else:
            query=m.Visitors.gql("ORDER BY %s %s" % (sort, order))
        visitors=query.fetch(rows, (page-1)*rows)
        rows=[]
        for v in visitors:
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
        count=query.count()
        obj={"total":count,"rows":rows}
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class list_visitors_6(webapp2.RequestHandler):
    def get(self):
        url="templates/list_visitors_6.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors_6(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        search_field=self.request.get("search_field")
        search_what=self.request.get("search_what")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="visit_time"
        if not len(order):
            order="desc"
        if len(search_field):
            if search_field=="ip_list":
                query=m.Visitors.gql("WHERE ip_list = :1", list(search_what))
            elif search_field=="user_agent_list":
                query=m.Visitors.gql("WHERE user_agent_list = :1", list(search_what))
            else:
                query=m.Visitors.all()
                query.filter(search_field + " >= ", search_what)
                query.filter(search_field + " < ", search_what + u'\ufffd') 
        else:
            query=m.Visitors.gql("ORDER BY %s %s" % (sort, order))
        visitors=query.fetch(rows, (page-1)*rows)
        rows=[]
        for v in visitors:
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
        count=query.count()
        obj={"total":count,"rows":rows}
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class main_1(webapp2.RequestHandler):
    def get(self):
        #check login session
        url="templates/main_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class sys_tabs(webapp2.RequestHandler):
    def get(self):
        #check login session
        url="templates/sys_tabs.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class MainHandler(webapp2.RequestHandler):
    def get(self):
        url="templates/default.htm"
        ip=self.request.remote_addr
        user_agent=os.environ.get("HTTP_USER_AGENT")
        #user_agent=self.request.headers.get("User-Agent")
        visitor=m.Visitors()
        visitor.ip=ip
        visitor.visit_time=datetime.now() + timedelta(hours=+8)
        visitor.user_agent=user_agent
        visitor.ip_list=list(ip)
        visitor.user_agent_list=list(user_agent)
        visitor.put()
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

app = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/easyui_1', easyui_1),
    ('/easyui_2', easyui_2),
    ('/easyui_3', easyui_3),
    ('/easyui_4', easyui_4),
    ('/login_4', login_4),
    ('/easyui_5', easyui_5),
    ('/login_5', login_5),
    ('/easyui_5_1', easyui_5_1),
    ('/home', home),
    ('/google_user_login_1', google_user_login_1),
    ('/google_user_login_2', google_user_login_2),
    ('/google_user_login_3', google_user_login_3),
    ('/google_user_login_4', google_user_login_4),
    ('/google_user_login_5', google_user_login_5),
    ('/list_visitors_1', list_visitors_1),
    ('/list_visitors_2', list_visitors_2),
    ('/get_visitors_2', get_visitors_2),
    ('/list_visitors_3', list_visitors_3),
    ('/get_visitors_3', get_visitors_3),
    ('/list_visitors_4', list_visitors_4),
    ('/get_visitors_4', get_visitors_4),
    ('/list_visitors_5', list_visitors_5),
    ('/get_visitors_5', get_visitors_5),
    ('/list_visitors_6', list_visitors_6),
    ('/get_visitors_6', get_visitors_6),
    ('/main_1', main_1),
    ('/sys_tabs', sys_tabs)
], debug=True)