# -*- coding: utf-8 -*-
from google.appengine.ext import db

class Members(db.Model):
    account=db.StringProperty()
    password=db.StringProperty()
    theme=db.StringProperty()
    is_admin=db.BooleanProperty()

class Visitors(db.Model):
    ip=db.StringProperty()
    ip_list=db.StringListProperty()
    visit_time=db.DateTimeProperty()
    user_agent=db.StringProperty()
    user_agent_list=db.StringListProperty()

class Settings(db.Model):
    site_title=db.StringProperty()
    site_theme=db.StringProperty()
    site_state=db.StringProperty()
    site_created_time=db.DateTimeProperty(auto_now_add=True)

class Board(db.Model):
    poster=db.StringProperty()
    subject=db.StringProperty()
    content=db.TextProperty()
    post_time=db.DateTimeProperty()

class Themes(db.Model):
    theme=db.StringProperty()

class Systabs(db.Model):
    tab_name=db.StringProperty()
    tab_label=db.StringProperty()
    tab_link=db.StringProperty()
    tab_tip=db.StringProperty()
    tab_order=db.IntegerProperty()
    tab_admin=db.BooleanProperty()

settings=Settings(key_name="settings",site_title="EasyUI-based CMS on GAE",
    site_theme="ui-sunny",site_state="")
settings.put()

member=Members(key_name="admin",account="admin",password="aaa",
    theme="default",is_admin=True)
member.put()
member=Members(key_name="guest",account="guest",password="guest",
    theme="black",is_admin=False)
member.put()

theme=Themes(key_name="default",theme="default")
theme.put()
theme=Themes(key_name="gray",theme="gray")
theme.put()
theme=Themes(key_name="black",theme="black")
theme.put()
theme=Themes(key_name="bootstrap",theme="bootstrap")
theme.put()
theme=Themes(key_name="metro",theme="metro")
theme.put()
theme=Themes(key_name="metro-blue",theme="metro-blue")
theme.put()
theme=Themes(key_name="metro-gray",theme="metro-gray")
theme.put()
theme=Themes(key_name="metro-green",theme="metro-green")
theme.put()
theme=Themes(key_name="metro-orange",theme="metro-orange")
theme.put()
theme=Themes(key_name="metro-red",theme="metro-red")
theme.put()
theme=Themes(key_name="ui-cupertino",theme="ui-cupertino")
theme.put()
theme=Themes(key_name="ui-dark-hive",theme="ui-dark-hive")
theme.put()
theme=Themes(key_name="ui-pepper-grinder",theme="ui-pepper-grinder")
theme.put()
theme=Themes(key_name="ui-sunny",theme="ui-sunny")
theme.put()

systab=Systabs(key_name="home",tab_name="home",tab_label=u"首頁",
    tab_link="/home",tab_order=0,tab_admin=False)
systab.put()
systab=Systabs(key_name="admin",tab_name="admin",tab_label=u"管理",
    tab_link="/admin",tab_order=1,tab_admin=True)
systab.put()