# -*- coding: utf-8 -*-
import os
from google.appengine.ext.webapp import template
import webapp2

class jquery_datatable(webapp2.RequestHandler):
    def get(self):
        url="jquery_datatable.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class extjs_datatable(webapp2.RequestHandler):
    def get(self):
        url="extjs_datatable.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class loginform1(webapp2.RequestHandler):
    def get(self):
        url="loginform1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class loginform2(webapp2.RequestHandler):
    def get(self):
        url="loginform2.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class form2handler(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        if (account=="admin" and password=="aaa"): 
	    content="{success:true}"
	else:
	    content="{success:false,errors:{account:'帳號或密碼錯誤'}}"
	self.response.out.write(content)

class MainHandler(webapp2.RequestHandler):
    def get(self):
        self.response.write('Hello world!')

app = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/jquery_datatable', jquery_datatable),
    ('/extjs_datatable', extjs_datatable),
    ('/loginform1', loginform1),
    ('/loginform2', loginform2),
    ('/form2handler', form2handler)
], debug=True)
