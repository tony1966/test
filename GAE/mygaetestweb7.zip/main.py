# -*- coding: utf-8 -*-
import os
from google.appengine.ext.webapp import template
import webapp2
import members
from google.appengine.ext import db

class jquery_datatable(webapp2.RequestHandler):
    def get(self):
        url="jquery_datatable.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class extjs_datatable(webapp2.RequestHandler):
    def get(self):
        url="extjs_datatable.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class loginform1(webapp2.RequestHandler):
    def get(self):
        url="loginform1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class loginform2(webapp2.RequestHandler):
    def get(self):
        url="loginform2.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class form2handler(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        if (account=="admin" and password=="aaa"): 
            content="{success:true}"
        else:
            content="{success:false,errors:{account:'帳號或密碼錯誤'}}"
        self.response.out.write(content)

class loginform3(webapp2.RequestHandler):
    def get(self):
        url="loginform3.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class form3handler(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=db.GqlQuery("""SELECT * FROM Members 
		                     WHERE account= :1 
							 AND password= :2""",
							 account,password)
        result=query.get()
        if result is None: 
	        content="{success:false,errors:{account:'帳號或密碼錯誤'}}"
        else:
            content="{success:true}"
        self.response.out.write(content)

class loginform4(webapp2.RequestHandler):
    def get(self):
        url="loginform4.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class form4handler(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=db.GqlQuery("""SELECT * FROM Members 
		                     WHERE account= :1 
							 AND password= :2""",
							 account,password)
        result=query.get()
        if result: 
	        content='{"result":"success"}'
        else:
            content='{"result":"failure","reason":"帳號或密碼錯誤"}'
        self.response.out.write(content)

class MainHandler(webapp2.RequestHandler):
    def get(self):
        url="default.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

app = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/jquery_datatable', jquery_datatable),
    ('/extjs_datatable', extjs_datatable),
    ('/loginform1', loginform1),
    ('/loginform2', loginform2),
    ('/form2handler', form2handler),
    ('/loginform3', loginform3),
    ('/form3handler', form3handler),
    ('/loginform4', loginform4),
    ('/form4handler', form4handler)
], debug=True)
