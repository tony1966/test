# -*- coding: utf-8 -*-
import os
from google.appengine.ext.webapp import template
import webapp2
import model as m
from google.appengine.ext import db
from google.appengine.api import users
from google.appengine.ext.webapp.util import login_required
import os
from datetime import timedelta
import datetime
import json
from webapp2_extras import sessions

class easyui_1(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

class easyui_2(webapp2.RequestHandler):
    def get(self):
        theme=self.request.get('theme',default_value='default')
        url="templates/easyui_2.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'theme':theme}) 
        self.response.out.write(content)

class easyui_3(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_3.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class easyui_4(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_4.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class login_4(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=db.GqlQuery("""SELECT * FROM Members 
                             WHERE account= :1 
                             AND password= :2""",
                             account,password)
        result=query.get()
        if result: 
            content='{"result":"success"}'
        else:
            content='{"result":"failure","reason":"帳號或密碼錯誤"}'
        self.response.out.write(content)

class easyui_5(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_5.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class login_5(webapp2.RequestHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=m.Members.gql("""WHERE account= :1  
                               AND password= :2""",
                               account,password)
        result=query.get()
        if result is None:  
            content='{"result":"failure","reason":"帳號或密碼錯誤"}'
        else:
            content='{"result":"success"}'            
        self.response.out.write(content)

class easyui_5_1(webapp2.RequestHandler):
    def get(self):
        url="templates/easyui_5_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class home(webapp2.RequestHandler):
    def get(self):
        url="templates/home.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class google_user_login_1(webapp2.RequestHandler):
    def get(self):
        user=users.get_current_user();
        if user:
            logout_url=users.create_logout_url(self.request.path)
            content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))  
        else:
            login_url=users.create_login_url(self.request.path)
            content=("您尚未登入 (<a href='%s'>登入</a>)" % login_url) 
        self.response.out.write(content)

class google_user_login_2(webapp2.RequestHandler):
    @login_required
    def get(self):
        user=users.get_current_user();
        logout_url=users.create_logout_url(self.request.path)
        content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))
        self.response.out.write(content)

class google_user_login_3(webapp2.RequestHandler):
    def get(self):
        user=users.get_current_user();
        logout_url=users.create_logout_url(self.request.path)
        nickname=user.nickname()
        content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))
        self.response.out.write(content)

class google_user_login_4(webapp2.RequestHandler):
    @login_required
    def get(self):
        url="templates/google_user_login_4.htm"
        user=users.get_current_user();
        nickname=user.nickname()
        email=user.email()
        logout_url=users.create_logout_url("/google_user_login_4")
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,
            {'nickname':nickname,'email':email,'logout_url':logout_url})
        self.response.out.write(content)

class google_user_login_5(webapp2.RequestHandler):
    @login_required
    def get(self):
        user=users.get_current_user();
        logout_url=users.create_logout_url(self.request.path)
        if users.is_current_user_admin():
            content="您是此應用程式的管理者!"
        else:
            content=("歡迎 %s!<br>您已經以 %s 帳號登入了! (<a href='%s'>登出</a>)" % 
                (user.nickname(), user.email(), logout_url))
        self.response.out.write(content)

class list_visitors_1(webapp2.RequestHandler):
    def get(self):
        query=m.Visitors.all()
        query.order("-visit_time")
        url="templates/list_visitors_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{"visitors":query}) 
        self.response.out.write(content)

class list_visitors_2(webapp2.RequestHandler):
    def get(self):
        url="templates/list_visitors_2.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors_2(webapp2.RequestHandler):
    def get(self):
        self.response.headers["Content-Type"]="application/json"
        query=m.Visitors.all()
        query.order("-visit_time")
        rows=[]
        count=0
        for v in query:
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
            count=count + 1
        obj={"total":count,"rows":rows}
        self.response.out.write(json.dumps(obj))

class list_visitors_3(webapp2.RequestHandler):
    def get(self):
        url="templates/list_visitors_3.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors_3(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        query=m.Visitors.all()
        query.order("-visit_time")
        visitors=query.fetch(rows, (page-1)*rows)
        rows=[]
        for v in visitors:
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
        count=query.count()
        obj={"total":count,"rows":rows}
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class list_visitors_4(webapp2.RequestHandler):
    def get(self):
        url="templates/list_visitors_4.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors_4(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="visit_time"
        if not len(order):
            order="desc"
        query=m.Visitors.gql("ORDER BY %s %s" % (sort, order))
        visitors=query.fetch(rows, (page-1)*rows)
        rows=[]
        for v in visitors:
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
        count=query.count()
        obj={"total":count,"rows":rows}
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class list_visitors_5(webapp2.RequestHandler):
    def get(self):
        url="templates/list_visitors_5.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors_5(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        search_field=self.request.get("search_field")
        search_what=self.request.get("search_what")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="visit_time"
        if not len(order):
            order="desc"
        if len(search_field):
            query=m.Visitors.all()
            query.filter(search_field + " >= ", search_what)
            query.filter(search_field + " < ", search_what + u'\ufffd') 
            if order=="desc":
                query.order("-" + search_field)
            else:
                query.order(search_field)
        else:
            query=m.Visitors.gql("ORDER BY %s %s" % (sort, order))
        visitors=query.fetch(rows, (page-1)*rows)
        rows=[]
        for v in visitors:
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
        count=query.count()
        obj={"total":count,"rows":rows}
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class list_visitors_6(webapp2.RequestHandler):
    def get(self):
        url="templates/list_visitors_6.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors_6(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        search_field=self.request.get("search_field")
        search_what=self.request.get("search_what")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="visit_time"
        if not len(order):
            order="desc"
        if len(search_field):
            if search_field=="ip_list":
                query=m.Visitors.gql("WHERE ip_list = :1", list(search_what))
            elif search_field=="user_agent_list":
                query=m.Visitors.gql("WHERE user_agent_list = :1", list(search_what))
            else:
                query=m.Visitors.all()
                query.filter(search_field + " >= ", search_what)
                query.filter(search_field + " < ", search_what + u'\ufffd') 
        else:
            query=m.Visitors.gql("ORDER BY %s %s" % (sort, order))
        visitors=query.fetch(rows, (page-1)*rows)
        rows=[]
        for v in visitors:
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
        count=query.count()
        obj={"total":count,"rows":rows}
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class main_1(webapp2.RequestHandler):
    def get(self):
        #check login session
        url="templates/main_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class systabs_1(webapp2.RequestHandler):
    def get(self):
        #check login session
        url="templates/systabs_1.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class BaseHandler(webapp2.RequestHandler):
    def dispatch(self):
        # Get a session store for this request.
        self.session_store=sessions.get_store(request=self.request)
        try:
            #Dispatch the request.
            webapp2.RequestHandler.dispatch(self)
        finally:
            #Save all sessions.
            self.session_store.save_sessions(self.response)
    @webapp2.cached_property
    def session(self):
        #Returns a session using the default cookie key.
        sess=self.session_store.get_session()
        #add some default values:
        if not sess.get("theme"):
            sess["theme"]="ui-sunny"
        return sess

class login(webapp2.RequestHandler):
    def get(self):
        s=m.Settings.get_by_key_name("settings")
        info={}
        info["site_title"]=s.site_title
        info["site_theme"]=s.site_theme
        url="templates/login.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{"info":info})
        self.response.out.write(content)

class login_check(BaseHandler):
    def post(self):
        account=self.request.get("account", default_value="unknown")
        password=self.request.get("password", default_value="unknown")
        query=m.Members.gql("""WHERE account= :1  
                               AND password= :2""",
                               account,password)
        result=query.get()
        if result is None: 
            content='{"result":"failure","reason":"帳號或密碼錯誤"}'
        else: 
            self.session['account']=result.account     #save session
            self.session['theme']=result.theme         #save session
            self.session['is_admin']=result.is_admin   #save session
            content='{"result":"success"}'            
        self.response.out.write(content)    

class main_2(BaseHandler):
    def get(self):
        info={}  #for storing parameters
        #check login session 
        account=self.session.get('account')
        if account: #already logged in
            info["account"]=account
            s=m.Settings.get_by_key_name("settings")
            info["site_title"]=s.site_title
            theme=self.session.get('theme')
            info["theme"]=theme
            today=datetime.date.today()
            week=[u"一",u"二",u"三",u"四",u"五",u"六",u"日"]
            info["greeting"]=u"您好! " + account + u", 今天是 " + \
                str(today.year) +  u" 年 " + str(today.month) + u" 月 " + \
                str(today.day) + u" 日 星期" + week[today.weekday()]
            theme_list=[]
            themes=m.Themes.all()
            #themes.order("theme")
            for t in themes:
                theme_list.append(t.theme)
            info["themes"]=theme_list
            url="templates/main_2.htm"
        else:  #not logged in
            s=m.Settings.get_by_key_name("settings")
            info["site_title"]=s.site_title
            info["site_theme"]=s.site_theme
            url="templates/login.htm"
        theme=self.session.get('theme')
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'info':info}) 
        self.response.out.write(content)

class systabs_2(BaseHandler):
    def get(self):
        systabs=m.Systabs.all()
        systabs.order("tab_order")  #sort by tab_order
        tabs=[]  #for storing tab objects
        is_admin=self.session.get('is_admin')  #True/False
        for t in systabs:
            tab={}
            tab["tab_label"]=t.tab_label
            tab["tab_link"]=t.tab_link
            if t.tab_admin:  #this tab is for admin only
                if is_admin: #current user is admin
                    tabs.append(tab)
            else:  #this tab is for registered users
                tabs.append(tab)
        url="templates/systabs_2.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{"tabs":tabs}) 
        self.response.out.write(content)

class admin(webapp2.RequestHandler):
    def get(self):
        url="templates/admin.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class change_theme(BaseHandler):
    def get(self):
        theme=self.request.get("theme")  #get selected theme
        self.session['theme']=theme  #update user session
        account=self.session.get('account')
        member=m.Members.get_by_key_name(account)  #retrieve entity
        member.theme=theme  
        member.put()  #update user theme in datastre

class logout(BaseHandler):
    def get(self):
        #check login session
        self.session.clear()
        self.redirect("/login")

class main_3(BaseHandler):
    def get(self):  
        #save visitor info
        ip=self.request.remote_addr
        #user_agent=os.environ.get("HTTP_USER_AGENT")
        user_agent=self.request.headers.get("User-Agent")
        visitor=m.Visitors()
        visitor.ip=ip
        visitor.visit_time=datetime.datetime.now() + timedelta(hours=+8)
        visitor.user_agent=user_agent
        visitor.ip_list=list(ip)
        visitor.user_agent_list=list(user_agent)
        visitor.put()
        #check login session 
        info={}  #for storing parameters
        account=self.session.get('account')
        if account: #already logged in
            info["account"]=account
            s=m.Settings.get_by_key_name("settings")
            info["site_title"]=s.site_title
            theme=self.session.get('theme')
            info["theme"]=theme
            today=datetime.date.today()
            week=[u"一",u"二",u"三",u"四",u"五",u"六",u"日"]
            info["greeting"]=u"您好! " + account + u", 今天是 " + \
                str(today.year) +  u" 年 " + str(today.month) + u" 月 " + \
                str(today.day) + u" 日 星期" + week[today.weekday()]
            theme_list=[]
            themes=m.Themes.all()
            #themes.order("theme")
            for t in themes:
                theme_list.append(t.theme)
            info["themes"]=theme_list
            url="templates/main_3.htm"
        else:  #not logged in
            s=m.Settings.get_by_key_name("settings")
            info["site_title"]=s.site_title
            info["site_theme"]=s.site_theme
            url="templates/login.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'info':info}) 
        self.response.out.write(content)

class systabs_3(BaseHandler):
    def get(self):
        systabs=m.Systabs.all()
        systabs.order("tab_order")  #sort by tab_order
        tabs=[]  #for storing tab objects
        is_admin=self.session.get('is_admin')  #True/False
        for t in systabs:
            tab={}
            tab["tab_label"]=t.tab_label
            tab["tab_link"]=t.tab_link
            if t.tab_admin:  #this tab is for admin only
                if is_admin: #current user is admin
                    tabs.append(tab)
            else:  #this tab is for registered users
                tabs.append(tab)
        url="templates/systabs_3.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{"tabs":tabs}) 
        self.response.out.write(content)

class list_visitors(webapp2.RequestHandler):
    def get(self):
        url="templates/list_visitors.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_visitors(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        search_field=self.request.get("search_field")
        search_what=self.request.get("search_what")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="visit_time"
        if not len(order):
            order="desc"
        if len(search_field):
            if search_field=="ip_list":
                query=m.Visitors.gql("WHERE ip_list = :1", list(search_what))
            elif search_field=="user_agent_list":
                query=m.Visitors.gql("WHERE user_agent_list = :1", list(search_what))
            else:
                query=m.Visitors.all()
                query.filter(search_field + " >= ", search_what)
                query.filter(search_field + " < ", search_what + u'\ufffd') 
        else:
            query=m.Visitors.gql("ORDER BY %s %s" % (sort, order))
        visitors=query.fetch(rows, (page-1)*rows)
        rows=[]
        for v in visitors:
            visit_time=v.visit_time.strftime("%Y-%m-%d %H:%M:%S")
            visitor={"ip":v.ip,
                     "visit_time":visit_time,
                     "user_agent":v.user_agent}
            rows.append(visitor)
        count=query.count()
        obj={"total":count,"rows":rows}
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class remove_visitor(webapp2.RequestHandler):
    def post(self):
        ip=self.request.get("ip")
        visit_time=self.request.get("visit_time")
        #dtobj=datetime.datetime.strptime(visit_time,"%Y-%m-%d %H:%M:%S")
        query=m.Visitors.all()
        query.filter("ip = ",ip)
        #query.filter("visit_time >= ",dtobj)
        visitor=query.fetch(1,0)
        db.delete(visitor)
        content='{"status":"success"}'            
        self.response.out.write(content)

class main_4(BaseHandler):
    def get(self):  
        #save visitor info
        ip=self.request.remote_addr
        #user_agent=os.environ.get("HTTP_USER_AGENT")
        user_agent=self.request.headers.get("User-Agent")
        visitor=m.Visitors()
        visitor.ip=ip
        visitor.visit_time=datetime.datetime.now() + timedelta(hours=+8)
        visitor.user_agent=user_agent
        visitor.ip_list=list(ip)
        visitor.user_agent_list=list(user_agent)
        visitor.put()
        #check login session 
        info={}  #for storing parameters
        account=self.session.get('account')
        if account: #already logged in
            info["account"]=account
            s=m.Settings.get_by_key_name("settings")
            info["site_title"]=s.site_title
            theme=self.session.get('theme')
            info["theme"]=theme
            #create param: greeting
            today=datetime.date.today()
            week=[u"一",u"二",u"三",u"四",u"五",u"六",u"日"]
            info["greeting"]=u"您好! " + account + u", 今天是 " + \
                str(today.year) +  u" 年 " + str(today.month) + u" 月 " + \
                str(today.day) + u" 日 星期" + week[today.weekday()]
            #create param: themes
            theme_list=[]
            themes=m.Themes.all()
            for t in themes:
                theme_list.append(t.theme)
            info["themes"]=theme_list
            #create param: headerlinks
            headerlinks=m.Headerlinks.all()
            headerlinks.order("-sequence")  #sort by sequence (reverse)
            link_list=[]  #for storing headerlinks objects
            for h in headerlinks:
                link={}
                link["title"]=h.title
                link["url"]=h.url
                link["target"]=h.target
                link["sequence"]=h.sequence
                link["hint"]=h.hint
                link_list.append(link)
            info["headerlinks"]=link_list
            url="templates/main_4.htm"
        else:  #not logged in
            s=m.Settings.get_by_key_name("settings")
            info["site_title"]=s.site_title
            info["site_theme"]=s.site_theme
            url="templates/login.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'info':info}) 
        self.response.out.write(content)

class systabs(BaseHandler):
    def get(self):
        systabs=m.Systabs.all()
        systabs.order("tab_order")  #sort by tab_order
        tabs=[]  #for storing tab objects
        is_admin=self.session.get('is_admin')  #True/False
        for t in systabs:
            tab={}
            tab["tab_label"]=t.tab_label
            tab["tab_link"]=t.tab_link
            if t.tab_admin:  #this tab is for admin only
                if is_admin: #current user is admin
                    tabs.append(tab)
            else:  #this tab is for registered users
                tabs.append(tab)
        url="templates/systabs.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{"tabs":tabs}) 
        self.response.out.write(content)

class list_headerlinks(webapp2.RequestHandler):
    def get(self):
        url="templates/list_headerlinks.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_headerlinks(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="sequence"
        if not len(order):
            order="asc"
        query=m.Headerlinks.gql("ORDER BY %s %s" % (sort, order))
        count=query.count()
        links=query.fetch(rows, (page-1)*rows)
        rows=[]  #for storing objects
        for h in links:
            link={"name":h.name,
                  "title":h.title,
                  "url":h.url,
                  "target":h.target,
                  "sequence":h.sequence,
                  "hint":h.hint}
            rows.append(link)
        obj={"total":count,"rows":rows}  #Easyui datagrid json format
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class add_headerlink(webapp2.RequestHandler):
    def post(self):
        name=self.request.get("name")
        #check entity if exist
        link=m.Headerlinks.get_by_key_name(name)
        if link: #already exist
            result='{"status":"failure","reason":"連結名稱已存在!"}'  
        else:  #new link
            headerlink=m.Headerlinks(key_name=name,name=name,
                title=self.request.get("title"),
                url=self.request.get("url"),
                target=self.request.get("target"),
                sequence=int(self.request.get("sequence")),
                hint=self.request.get("hint")
                )
            headerlink.put()
            result='{"status":"success"}'         
        self.response.out.write(result) 

class update_headerlink(webapp2.RequestHandler):
    def post(self):
        name=self.request.get("name")
        #get entity from store
        link=m.Headerlinks.get_by_key_name(name)
        if link: #entity exist
            link.title=self.request.get("title")
            link.url=self.request.get("url")
            link.target=self.request.get("target")
            link.sequence=int(self.request.get("sequence"))
            link.hint=self.request.get("hint")
            link.put()
            result='{"status":"success"}'
        else:  #link not existed
            result='{"status":"failure","reason":"連結不存在!"}'         
        self.response.out.write(result) 

class remove_headerlink(webapp2.RequestHandler):
    def post(self):
        name=self.request.get("name")
        #get entity from store
        link=m.Headerlinks.get_by_key_name(name)
        if link: #entity exist
            db.delete(link)            
            result='{"status":"success"}'
        else:  #link not existed
            result='{"status":"failure","reason":"連結不存在!"}'         
        self.response.out.write(result) 

class main_5(BaseHandler):
    def get(self):  
        #save visitor info
        ip=self.request.remote_addr
        user_agent=self.request.headers.get("User-Agent")
        visitor=m.Visitors()
        visitor.ip=ip
        visitor.visit_time=datetime.datetime.now() + timedelta(hours=+8)
        visitor.user_agent=user_agent
        visitor.ip_list=list(ip)
        visitor.user_agent_list=list(user_agent)
        visitor.put()
        #check login session 
        info={}  #for storing parameters
        account=self.session.get('account')
        if account: #already logged in
            info["account"]=account
            s=m.Settings.get_by_key_name("settings")
            info["site_title"]=s.site_title
            theme=self.session.get('theme')
            info["theme"]=theme
            #create param: greeting
            today=datetime.date.today()
            week=[u"一",u"二",u"三",u"四",u"五",u"六",u"日"]
            info["greeting"]=u"您好! " + account + u", 今天是 " + \
                str(today.year) +  u" 年 " + str(today.month) + u" 月 " + \
                str(today.day) + u" 日 星期" + week[today.weekday()]
            #create param: themes
            theme_list=[]
            themes=m.Themes.all()
            for t in themes:
                theme_list.append(t.theme)
            info["themes"]=theme_list
            #create param: headerlinks
            headerlinks=m.Headerlinks.all()
            headerlinks.order("-sequence")  #sort by sequence (reverse)
            link_list=[]  #for storing headerlinks objects
            for h in headerlinks:
                link={}
                link["title"]=h.title
                link["url"]=h.url
                link["target"]=h.target
                link["sequence"]=h.sequence
                link["hint"]=h.hint
                link_list.append(link)
            info["headerlinks"]=link_list
            #create param: navblocks & navlinks
            navblocks=m.Navblocks.all()
            navblocks.filter("display =",True)
            navblocks.order("sequence")  #sort by sequence            
            navblock_list=[]  #for storing navblocks objects
            for nb in navblocks:
                navblock={}
                navblock["title"]=nb.title  #store block title
                #query nvavlinks belongs to this block
                query=m.Navlinks.all()
                navlinks=query.filter("block_name =",nb.name)
                navlinks.order("sequence")
                navlink_list=[]  #for storing navblinks objects 
                for nl in navlinks:
                    navlink={}
                    navlink["title"]=nl.title
                    navlink["url"]=nl.url
                    navlink["target"]=nl.target
                    navlink["hint"]=nl.hint
                    navlink_list.append(navlink) #store this link
                navblock["navlinks"]=navlink_list #store block links 
                navblock_list.append(navblock)  #store this block
            info["navblocks"]=navblock_list
            url="templates/main_5.htm"
        else:  #not logged in
            s=m.Settings.get_by_key_name("settings")
            info["site_title"]=s.site_title
            info["site_theme"]=s.site_theme
            url="templates/login.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'info':info}) 
        self.response.out.write(content)

class list_navblocks(webapp2.RequestHandler):
    def get(self):
        url="templates/list_navblocks.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{}) 
        self.response.out.write(content)

class get_navblocks(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="sequence"
        if not len(order):
            order="asc"
        query=m.Navblocks.gql("ORDER BY %s %s" % (sort, order))
        count=query.count()
        blocks=query.fetch(rows, (page-1)*rows)
        rows=[]  #for storing objects
        for b in blocks:
            block={"name":b.name,
                   "title":b.title,
                   "sequence":b.sequence,
                   "display":b.display}
            rows.append(block)
        obj={"total":count,"rows":rows}  #Easyui datagrid json format
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class add_navblock(webapp2.RequestHandler):
    def post(self):
        name=self.request.get("name")
        display=self.request.get("display")
        if display=="True":
            display=True
        else:
            display=False
        #check entity if exist
        block=m.Navblocks.get_by_key_name(name)
        if block: #already exist
            result='{"status":"failure","reason":"導覽區塊已存在!"}'  
        else:  #new block
            navblock=m.Navblocks(key_name=name,name=name,
                title=self.request.get("title"),
                sequence=int(self.request.get("sequence")),
                display=display
                )
            navblock.put()
            result='{"status":"success"}'         
        self.response.out.write(result) 

class update_navblock(webapp2.RequestHandler):
    def post(self):
        name=self.request.get("name")
        display=self.request.get("display")
        if display=="True":
            display=True
        else:
            display=False
        #get entity from store
        block=m.Navblocks.get_by_key_name(name)
        if block: #entity exist
            block.title=self.request.get("title")
            block.sequence=int(self.request.get("sequence"))
            block.display=display
            block.put()
            result='{"status":"success"}'
        else:  #block not existed
            result='{"status":"failure","reason":"導覽區塊不存在!"}'         
        self.response.out.write(result) 

class remove_navblock(webapp2.RequestHandler):
    def post(self):
        name=self.request.get("name")
        #get entity from store
        block=m.Navblocks.get_by_key_name(name)
        if block: #entity exist
            db.delete(block)  
            #delete navlinks belong to this navblock
            query=m.Navlinks.all()
            links=query.filter("block_name",name) 
            for link in links:  
                db.delete(link)
            result='{"status":"success"}'
        else:  #block not existed
            result='{"status":"failure","reason":"導覽區塊不存在!"}'         
        self.response.out.write(result) 

class list_navlinks(webapp2.RequestHandler):
    def get(self):
        blocks=m.Navblocks.all()
        info=[]
        for b in blocks:
            block={}
            block["block_name"]=b.name
            block["block_title"]=b.title
            #block["block_title"]=b.title + " (" + b.name + ")"
            info.append(block)
        url="templates/list_navlinks.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{"info":info}) 
        self.response.out.write(content)

class get_navlinks(webapp2.RequestHandler):
    def post(self):
        page=self.request.get("page")
        rows=self.request.get("rows")
        sort=self.request.get("sort")
        order=self.request.get("order")
        if len(page):
            page=int(page)
        else:
            page=1
        if len(rows):
            rows=int(rows)
        else:
            rows=10
        if not len(sort):
            sort="sequence"
        if not len(order):
            order="asc"
        query=m.Navlinks.gql("ORDER BY %s %s" % (sort, order))
        count=query.count()
        links=query.fetch(rows, (page-1)*rows)
        rows=[]  #for storing objects
        for h in links:
            link={"name":h.name,
                  "title":h.title,
                  "url":h.url,
                  "target":h.target,
                  "sequence":h.sequence,
                  "block_name":h.block_name,
                  "hint":h.hint}
            rows.append(link)
        obj={"total":count,"rows":rows}  #Easyui datagrid json format
        self.response.headers["Content-Type"]="application/json"
        self.response.out.write(json.dumps(obj))

class add_navlink(webapp2.RequestHandler):
    def post(self):
        name=self.request.get("name")
        #check entity if exist
        link=m.Navlinks.get_by_key_name(name)
        if link: #already exist
            result='{"status":"failure","reason":"連結名稱已存在!"}'  
        else:  #new link
            navlink=m.Navlinks(key_name=name,name=name,
                title=self.request.get("title"),
                url=self.request.get("url"),
                target=self.request.get("target"),
                sequence=int(self.request.get("sequence")),
                block_name=self.request.get("block_name"),
                hint=self.request.get("hint")
                )
            navlink.put()
            result='{"status":"success"}'         
        self.response.out.write(result) 

class update_navlink(webapp2.RequestHandler):
    def post(self):
        name=self.request.get("name")
        #get entity from store
        link=m.Navlinks.get_by_key_name(name)
        if link: #entity exist
            link.title=self.request.get("title")
            link.url=self.request.get("url")
            link.target=self.request.get("target")
            link.sequence=int(self.request.get("sequence"))
            link.block_name=self.request.get("block_name")
            link.hint=self.request.get("hint")
            link.put()
            result='{"status":"success"}'
        else:  #link not existed
            result='{"status":"failure","reason":"連結不存在!"}'         
        self.response.out.write(result) 

class remove_navlink(webapp2.RequestHandler):
    def post(self):
        name=self.request.get("name")
        #get entity from store
        link=m.Navlinks.get_by_key_name(name)
        if link: #entity exist
            db.delete(link)            
            result='{"status":"success"}'
        else:  #link not existed
            result='{"status":"failure","reason":"連結不存在!"}'         
        self.response.out.write(result) 

class settings(webapp2.RequestHandler):
    def get(self):
        info={}  #for storing parameters
        #query settings from datastore
        settings=m.Settings.get_by_key_name("settings")
        if settings: #entity exist
            info["site_title"]=settings.site_title
            info["site_theme"]=settings.site_theme
            info["site_state"]=settings.site_state
        else:
            info["site_title"]=""
            info["site_theme"]="default"
            info["site_state"]="off"
        #query Themes from datastore
        themes=m.Themes.all()
        theme_list=[]
        for t in themes:
            theme_list.append(t.theme)
        info["themes"]=theme_list
        url="templates/settings.htm"
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{'info':info}) 
        self.response.out.write(content)

class update_settings(webapp2.RequestHandler):
    def post(self):
        #get entity from store
        settings=m.Settings.get_by_key_name("settings")
        if settings: #entity exist
            settings.site_title=self.request.get("site_title")
            settings.site_theme=self.request.get("site_theme")
            settings.site_state=self.request.get("site_state")
            settings.put()
            result='{"status":"success"}'
        else:  #entity not existed
            result='{"status":"failure"}'         
        self.response.out.write(result)

class MainHandler(webapp2.RequestHandler):
    def get(self):
        url="templates/default.htm"
        ip=self.request.remote_addr
        user_agent=os.environ.get("HTTP_USER_AGENT")
        #user_agent=self.request.headers.get("User-Agent")
        visitor=m.Visitors()
        visitor.ip=ip
        visitor.visit_time=datetime.datetime.now() + timedelta(hours=+8)
        visitor.user_agent=user_agent
        visitor.ip_list=list(ip)
        visitor.user_agent_list=list(user_agent)
        visitor.put()
        path=os.path.join(os.path.dirname(__file__), url)
        content=template.render(path,{})
        self.response.out.write(content)

config={}
config['webapp2_extras.sessions']={'secret_key':'my-super-secret-key'}
app = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/easyui_1', easyui_1),
    ('/easyui_2', easyui_2),
    ('/easyui_3', easyui_3),
    ('/easyui_4', easyui_4),
    ('/login_4', login_4),
    ('/easyui_5', easyui_5),
    ('/login_5', login_5),
    ('/easyui_5_1', easyui_5_1),
    ('/home', home),
    ('/google_user_login_1', google_user_login_1),
    ('/google_user_login_2', google_user_login_2),
    ('/google_user_login_3', google_user_login_3),
    ('/google_user_login_4', google_user_login_4),
    ('/google_user_login_5', google_user_login_5),
    ('/list_visitors_1', list_visitors_1),
    ('/list_visitors_2', list_visitors_2),
    ('/get_visitors_2', get_visitors_2),
    ('/list_visitors_3', list_visitors_3),
    ('/get_visitors_3', get_visitors_3),
    ('/list_visitors_4', list_visitors_4),
    ('/get_visitors_4', get_visitors_4),
    ('/list_visitors_5', list_visitors_5),
    ('/get_visitors_5', get_visitors_5),
    ('/list_visitors_6', list_visitors_6),
    ('/get_visitors_6', get_visitors_6),
    ('/main_1', main_1),
    ('/systabs_1', systabs_1),
    ('/login', login),
    ('/login_check', login_check),
    ('/main_2', main_2),
    ('/systabs_2', systabs_2),
    ('/admin', admin),
    ('/change_theme', change_theme),
    ('/logout', logout),
    ('/main_3', main_3),
    ('/systabs_3', systabs_3),
    ('/list_visitors', list_visitors),
    ('/get_visitors', get_visitors),
    ('/remove_visitor', remove_visitor),
    ('/main_4', main_4),
    ('/systabs', systabs),
    ('/list_headerlinks', list_headerlinks),
    ('/get_headerlinks', get_headerlinks),
    ('/add_headerlink', add_headerlink),
    ('/update_headerlink', update_headerlink),
    ('/remove_headerlink', remove_headerlink),    
    ('/main_5', main_5),
    ('/list_navblocks', list_navblocks),
    ('/get_navblocks', get_navblocks),
    ('/add_navblock', add_navblock),
    ('/update_navblock', update_navblock),
    ('/remove_navblock', remove_navblock),
    ('/list_navlinks', list_navlinks),
    ('/get_navlinks', get_navlinks),
    ('/add_navlink', add_navlink),
    ('/update_navlink', update_navlink),
    ('/remove_navlink', remove_navlink),
    ('/settings', settings),
    ('/update_settings', update_settings)
], debug=True, config=config)