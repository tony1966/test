<?php
define('MYSQL_ADDRESS','localhost');
define('MYSQL_USERNAME','root');
define('MYSQL_PASSWORD','mysql');
define('DATABASE','easyuicms');
?>