<?php
session_start();
require_once("dbsettings.php");   //匯入資料庫設定檔 (必須)
require_once("lib/mysql.php");
?>
<div id="home-tab" class="easyui-tabs" data-options="fit:'true'">
<?php 
$SQL="SELECT * FROM `sys_tabs`";
if ((int)$_SESSION["user_level"]==9) {$SQL .= " ORDER BY tab_order";}
else {$SQL .= " WHERE NOT tab_level=9 ORDER BY tab_order";}
$RS=run_sql($SQL);
if (is_array($RS)) {
  for ($i=0; $i<count($RS); $i++) { 
    $label=$RS[$i]["tab_label"];
?>
  <div class="tab" title="<?php echo $label?>"></div>
<?php
    }
  }
?>
</div>