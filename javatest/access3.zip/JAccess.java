import java.sql.*;
public class JAccess {
  static Connection conn;
  static Statement stat;
  public static void connect(String database) { 
    try {
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
      String dsn="jdbc:odbc:Driver={Microsoft Access Driver (*.mdb)};" +
                 "DBQ=" + database + ";DriverID=22;READONLY=false}"; 
      conn=DriverManager.getConnection(dsn, "", ""); 
      stat=conn.createStatement();
      }
    catch (Exception e) {System.out.println(e);} 
    }
  public static void disconnect() {
    try {conn.close();}
    catch (Exception e) {System.out.println(e);}
    conn=null;
    stat=null;
    }
  public static ResultSet run(String SQL) {
    ResultSet rs=null;
    try {  
		  if (SQL.indexOf("SELECT")==-1) {stat.executeUpdate(SQL);}
		  else {rs=stat.executeQuery(SQL);}
      }
    catch (Exception e) {System.out.println(e);}
    return rs;
    }
  }